public class Main 
{
  public static void main(String[] args) 
  {
     //Instantiating and testing a Player object
     System.out.println("Testing Player Object - Warrior argument");
     Player player1 = new Player("Warrior");
     
     
     //Instantiating and testing a Warrior Object  
     System.out.println("Testing Warrior Object");
     Warrior player2 = new Warrior();
     
    //Instantiating and Testing a Wizard Object
     System.out.println("Testing Wizard Object");
     Wizard player3 = new Wizard();
     
    //Testing Modified Warrior
     System.out.println("Testing Updated Warrior Object");
     Warrior player4 = new Warrior();
     
    //Testing Modified Wizard 
     System.out.println("Testing Updated Wizard Object");
     Wizard player5 = new Wizard();
     
     
  }
}